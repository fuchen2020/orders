<?php
/**
 * Created by PhpStorm.
 * Author: Floating dust
 * Date: 2018-04-29
 * Time: 13:17
 */

namespace app\api\model;


use think\Model;

class SmsCode extends Model
{
    protected $autoWriteTimestamp = false;
}