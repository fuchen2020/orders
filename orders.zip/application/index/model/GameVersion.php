<?php
/**
 * Created by PhpStorm.
 * Author: Floating dust
 * Date: 2018-04-30
 * Time: 19:31
 */

namespace app\index\model;


use think\Model;

class GameVersion extends Model
{
    protected $autoWriteTimestamp = false;
    protected $table='kami_gameversion';
}