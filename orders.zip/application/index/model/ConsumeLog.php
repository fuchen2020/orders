<?php
/**
 * Created by PhpStorm.
 * Author: Floating dust
 * Date: 2018-04-30
 * Time: 1:16
 */

namespace app\index\model;


use think\Model;

class ConsumeLog extends Model
{
    protected $autoWriteTimestamp = false;
}