<?php
/**
 * Created by PhpStorm.
 * Author: Floating dust
 * Date: 2018-04-30
 * Time: 22:57
 */

namespace app\index\model;


use think\Model;

class Cards extends Model
{
    protected $autoWriteTimestamp = false;
}